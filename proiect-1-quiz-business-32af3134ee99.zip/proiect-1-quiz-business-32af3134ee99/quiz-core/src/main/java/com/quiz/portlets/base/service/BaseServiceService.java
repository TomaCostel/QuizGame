package com.quiz.portlets.base.service;

public interface BaseServiceService {
}
