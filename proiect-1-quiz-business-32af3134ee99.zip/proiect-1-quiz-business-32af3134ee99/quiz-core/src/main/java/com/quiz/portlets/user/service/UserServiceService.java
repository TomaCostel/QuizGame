package com.quiz.portlets.user.service;

public interface UserServiceService {
}
