package com.quiz.common.pojo.common;

import java.io.Serial;
import java.io.Serializable;

public class CommonDTO implements Serializable {
    @Serial
    private static final long serialVersionUID = -8515449552642585317L;
}
