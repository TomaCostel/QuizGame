package com.quiz.common.pojo.common;

import java.io.Serial;

public class UserDTO extends CommonDTO{
    @Serial
    private static final long serialVersionUID = 6501044408013827216L;
}
