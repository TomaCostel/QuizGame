package com.quiz.common.pojo.request;

import com.quiz.common.pojo.common.CommonDTO;

import java.io.Serial;

public class CommonRequestDTO extends CommonDTO {
    @Serial
    private static final long serialVersionUID = -8915907351903279086L;
}
