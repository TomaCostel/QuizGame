export default function Quizzes(){
    
}