package com.quiz.manager.user.impl;

import com.quiz.manager.user.service.UserModificationManager;
import org.springframework.stereotype.Service;

@Service
public class UserModificationManagerImpl implements UserModificationManager {
}