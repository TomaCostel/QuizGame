package com.quiz.common.pojo.response;

import com.quiz.common.pojo.common.CommonDTO;

import java.io.Serial;

public class CommonResponseDTO extends CommonDTO {
    @Serial
    private static final long serialVersionUID = 9171960818636208127L;
}
