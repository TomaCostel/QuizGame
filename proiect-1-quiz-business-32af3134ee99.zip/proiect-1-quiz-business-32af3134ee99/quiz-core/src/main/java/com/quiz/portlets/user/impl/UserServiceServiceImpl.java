package com.quiz.portlets.user.impl;

import com.quiz.portlets.base.impl.BaseServiceServiceImpl;
import com.quiz.portlets.user.service.UserServiceService;
import org.springframework.stereotype.Controller;

@Controller
public class UserServiceServiceImpl extends BaseServiceServiceImpl implements UserServiceService {
}
