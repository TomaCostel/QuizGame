package com.quiz.portlets.base.impl;

import com.quiz.portlets.base.service.BaseServiceService;

public class BaseServiceServiceImpl implements BaseServiceService {
}
