package com.quiz.manager.user.service;

public interface UserModificationManager {
}
