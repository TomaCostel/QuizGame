export default function CreateQuiz(){
    
}